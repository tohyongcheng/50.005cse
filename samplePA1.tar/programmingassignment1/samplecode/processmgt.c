#include <errno.h>
#include <string.h>   //str
#include <stdio.h>
#include <unistd.h>   //pid
#include <stdlib.h>   //malloc

#define INELIGIBLE 0
#define READY 1
#define RUNNING 2
#define FINISHED 3

#define MAX_LENGTH 1024
#define MAX_CHILDREN 10
#define MAX_NODES 50

int makeargv(const char *s, const char *delimiters, char ***argvp) {
	int error;
	int i;
	int numtokens;
	const char *snew;
	char *t;

	if ((s == NULL) || (delimiters == NULL) || (argvp == NULL)) {
		errno = EINVAL;
		return -1;
	}
	*argvp = NULL;
	snew = s + strspn(s, delimiters);
	if ((t = (char*)malloc(strlen(snew) + 1)) == NULL)
		return -1;
	strcpy(t,snew);
	numtokens = 0;
	if (strtok(t, delimiters) != NULL)
		for (numtokens = 1; strtok(NULL, delimiters) != NULL; numtokens++) ;

	if ((*argvp = (char**)malloc((numtokens + 1)*sizeof(char *))) == NULL) {
		error = errno;
		free(t);
		errno = error;
		return -1;
	}

	if (numtokens == 0)
		free(t);
	else {
		strcpy(t,snew);
		**argvp = strtok(t,delimiters);
		for (i=1; i<numtokens; i++)
			*((*argvp) +i) = strtok(NULL,delimiters);
	}
	*((*argvp) + numtokens) = NULL;
	return numtokens;
}

void freemakeargv(char **argv) {
	if (argv == NULL)
		return;
	if (*argv != NULL)
		free(*argv);
	free(argv);
}

typedef struct node {
  int id;
  char prog[MAX_LENGTH];
  char input[MAX_LENGTH];
  char output[MAX_LENGTH];
  int children[MAX_CHILDREN];
  int num_children;
  int status;
  pid_t pid;
} node_t;
/**
 * Parse the input line at s, and populate the node at n, which will
 * have id set to id.
 * Return 0 on success or -1 and set errno on failure.
 */
static int parse_input_line(char *s, int id, node_t *n) {

  char **strings;
  char **child_list;
  int c = 0;

  /* Split the line on ":" delimiters */
  if (makeargv(s, ":", &strings) == -1) {
    return -1;
  }

  /* Parse the space-delimited child list */
  if (makeargv(strings[1], " ", &child_list) == -1) {
    freemakeargv(strings);
    return -1;
  }

  strcpy(n->prog, strings[0]);
	fprintf(stderr,"n=%d n->prog=%s\n",id,n->prog);
  strcpy(n->input, strings[2]);
	fprintf(stderr,"n=%d n->input=%s\n",id,n->input);
  strcpy(n->output, strings[3]);
	fprintf(stderr,"n=%d n->output=%s\n",id,n->output);
  n->id = id;
	fprintf(stderr,"n=%d n->id=%d\n",id,id);
  n->num_children = 0;

  if (strcmp(child_list[c], "none") != 0) {
    for (c = 0; child_list[c] != NULL; c++) {
      n->children[c] = atoi(child_list[c]);
	fprintf(stderr,"n=%d n->child[%d]=%d\n",id,c,n->children[c]);
      n->num_children++;
    }
  }
	fprintf(stderr,"n=%d n->numchildren=%d\n",id,n->num_children);
  return 0;
}

/**
 * Parse the file at filename, and populate the array at n.
 * Return the number of nodes parsed on success, or -1 and set errno on
 * failure.
 */
static int parse_graph_file(char *filename, node_t *n) {

  FILE *f;
  char buf[MAX_LENGTH];
  int errno_copy;
  int id = 0;

  if ((f = fopen(filename,"r")) == NULL) {
    return -1;
  }

  while (fgets(buf, MAX_LENGTH, f) != NULL) {

    /* fgets retained the trailing newline; get rid of it */
    strtok(buf, "\n");

    if (parse_input_line(buf, id, n) == 0) {
      n++;
      id++;
    }
    else {
      return -1;
    }
  }

  /*
   * Make sure that we actually reached the end of the file, and close it.  The
   * error-handling seems a bit odd here, but it's just because we want to
   * retain any errno value that occurred during fgets rather than stomping on
   * it with a possible fclose errno value.
   */
  if (ferror(f)) {
    errno_copy = errno;
    fclose(f);  /* Ignore error; it's not what we want to report */
    errno = errno_copy;
    return -1;
  }
  if (fclose(f) == EOF) {
    return -1;
  }
  
  /* Otherwise return the number of nodes parsed */
  printf ("the number of nodes=%d\n", id);
  return id;
  
}

int main(int argc, char **argv) {
	node_t nodes[MAX_NODES];
	int num;
	
	if (argc != 2){
		fprintf(stderr, "usage: %s graph-file\n", argv[0]);
		return EXIT_FAILURE;
	}
	if ((num = parse_graph_file(argv[1], nodes)) == -1) {
		perror("Failed to parse graph file");
		return EXIT_FAILURE;
	}
	return EXIT_SUCCESS;
}

